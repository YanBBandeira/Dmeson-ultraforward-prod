import numpy as np
import pandas as pd
from pathlib import Path 

#1. Configurações e caminhos
DATA_DIR = Path("Codes/Analise/data")